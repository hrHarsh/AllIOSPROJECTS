//
//  ViewController.swift
//  Animations
//
//  Created by Appinventiv on 13/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var viewOutlet: UIView!
    @IBOutlet weak var labelanime: UILabel!
    
    @IBOutlet weak var bottomView: UIView!
    var timer = Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(rotate), userInfo: nil, repeats: true)
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(rotateBottom), userInfo: nil, repeats: true)
    }
    @objc func rotate(){
        UIView.transition(with: viewOutlet, duration: 0.1, options: .transitionFlipFromBottom, animations: {
            self.viewOutlet.backgroundColor = UIColor.black
        }, completion: nil)
    }
    @objc func rotateBottom(){
        UIView.transition(with: bottomView, duration: 1, options: .transitionCurlDown, animations: {
            self.bottomView.backgroundColor = UIColor.black
        }, completion: nil)
    }

}

