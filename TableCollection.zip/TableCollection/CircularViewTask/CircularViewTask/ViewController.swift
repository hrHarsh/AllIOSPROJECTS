//
//  ViewController.swift
//  CircularViewTask
//
//  Created by Appinventiv on 12/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    var width : CGFloat = 0.0
    var height : CGFloat = 0.0
    var arr = [#imageLiteral(resourceName: "Fast"),#imageLiteral(resourceName: "Slow"),#imageLiteral(resourceName: "Reverb"),#imageLiteral(resourceName: "Echo")]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func toggleButton(_ sender: UIButton) {
        sender.isSelected.toggle()
        let animate = sender.isSelected ? 0 : 1
        
        if animate == 0{
        
            UIView.animate(withDuration: 5, delay: 1, options: [.curveEaseInOut,.curveLinear], animations: {
            
                if let flowLayout = self.collectionView.collectionViewLayout as? UICollectionViewFlowLayout{
                    let widthofCell = (self.collectionView.bounds.width - 10)/2
                    flowLayout.itemSize = CGSize(width:widthofCell,height: widthofCell)
                    flowLayout.minimumLineSpacing = CGFloat(10)
//                    flowLayout.minimumInteritemSpacing = CGFloat(10)
                }
            }, completion: nil)
        }else if animate == 1{
            UIView.animate(withDuration: 5, delay: 1, options: [.transitionCurlUp], animations: {
                if let flowLayout = self.collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
                    
                    flowLayout.itemSize = CGSize(width:self.width,height: self.height)
                    flowLayout.minimumLineSpacing = CGFloat(10)
//                    flowLayout.minimumInteritemSpacing = CGFloat(10)
                }
            }, completion: nil)
        }
    }
}

extension ViewController : UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        
        
    }
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }

    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        cell.imagecycle.image = arr[indexPath.row]
        height = cell.frame.height
        width = cell.frame.width
        return cell
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        var reusableview: UICollectionReusableView? = nil
        
        if kind == UICollectionView.elementKindSectionHeader {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "header", for: indexPath) as! CollectionReusableView
            headerView.headerLabel.text = "Hello Header"
            headerView.headerLabel.textAlignment = .center
            reusableview = headerView
        }
        
        if kind == UICollectionView.elementKindSectionFooter {
            let footerview = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "footer", for: indexPath) as! CollectionReusableView
            footerview.footerLAbel.text = "Hello Footer"
            footerview.footerLAbel.textAlignment = .center
            reusableview = footerview
        }
        
        return reusableview!
    }
}





