//
//  CollectionReusableView.swift
//  CircularViewTask
//
//  Created by Appinventiv on 12/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class CollectionReusableView: UICollectionReusableView {
    @IBOutlet weak var headerLabel: UILabel!
    @IBOutlet weak var footerLAbel: UILabel!
}
