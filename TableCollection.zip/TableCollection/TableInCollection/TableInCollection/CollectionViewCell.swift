//
//  CollectionViewCell.swift
//  TableInCollection
//
//  Created by Appinventiv on 12/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collectionLabel: UILabel!
}
