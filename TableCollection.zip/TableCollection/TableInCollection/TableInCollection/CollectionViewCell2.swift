//
//  CollectionViewCell2.swift
//  TableInCollection
//
//  Created by Appinventiv on 12/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class CollectionViewCell2: UICollectionViewCell {
    
    
    @IBOutlet weak var collectionlabel2nd: UILabel!
}
