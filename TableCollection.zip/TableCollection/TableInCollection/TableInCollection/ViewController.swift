//
//  ViewController.swift
//  TableInCollection
//
//  Created by Appinventiv on 12/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var arr = ["A","B","C"]
    var arr2 = ["1","2","3"]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }


}
extension ViewController: UITableViewDataSource , UITableViewDelegate{
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.view.bounds.height/2
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
            
            if let flowlayout = cell.collectionView.collectionViewLayout as? UICollectionViewFlowLayout{
                flowlayout.minimumLineSpacing = 10
                flowlayout.minimumInteritemSpacing = 10
                flowlayout.scrollDirection = .horizontal
            }
            
            return cell
        }else if indexPath.section == 1{
            let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell2", for: indexPath) as! TableViewCell2
            if let flowlayout = cell.collectionView.collectionViewLayout as? UICollectionViewFlowLayout{
                flowlayout.minimumLineSpacing = 10
                flowlayout.minimumInteritemSpacing = 10
                flowlayout.scrollDirection = .vertical
            }
            return cell
        }
        fatalError()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
}

extension ViewController: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 3
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if (collectionView.superview?.superview) is TableViewCell {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
            cell.collectionLabel.text = self.arr[indexPath.row]
            return cell
        }else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell2", for: indexPath) as! CollectionViewCell2
            cell.collectionlabel2nd.text = self.arr2[indexPath.row]
            return cell
        }
//        fatalError()
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
}
