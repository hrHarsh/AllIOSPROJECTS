//
//  ViewController.swift
//  FlippedClock
//
//  Created by Appinventiv on 13/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var meridian: UILabel!
    @IBOutlet weak var secondsLabel: UILabel!
    @IBOutlet weak var minutesLabel: UILabel!
    @IBOutlet weak var hoursLabel: UILabel!
    var timer = Timer()
    var secondsCount = 0
    var minutesCount = 0
    var hoursCount = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.update), userInfo: nil, repeats: true)
        let seconds = Int(Calendar.current.component(.second, from: Date()))
        let minutes = Int(Calendar.current.component(.minute, from: Date()))
        let hours = Int(Calendar.current.component(.hour, from: Date()))
        secondsCount = seconds
        minutesCount = minutes
        hoursCount = hours
        secondsLabel.text = String(seconds)
        minutesLabel.text = String(minutes)
        hoursLabel.text = String(hours)
        print(secondsCount,minutesCount,hoursCount)
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
    }
    @objc func update(){
        if hoursCount<12{
            meridian.text = "AM"
        }else{
            meridian.text = "PM"
        }
        secondsCount += 1
        UIView.transition(with: self.secondsLabel, duration: 1, options: .transitionFlipFromBottom, animations: {
            self.secondsLabel.backgroundColor = UIColor.black
            }, completion: nil)
        secondsLabel.text = String(secondsCount)
        if secondsCount == 60{
            UIView.transition(with: self.minutesLabel, duration: 1, options: .transitionCurlUp, animations: {
                self.minutesLabel.backgroundColor = UIColor.black
                }, completion: nil)
            minutesCount += 1
            minutesLabel.text = String(minutesCount)
            secondsCount = 0
        }
        if minutesCount == 60{
            UIView.transition(with: self.hoursLabel, duration: 1, options: .showHideTransitionViews, animations: {
                self.hoursLabel.backgroundColor = UIColor.black
            }, completion: nil)
            hoursCount += 1
            hoursLabel.text = String(hoursCount)
            minutesCount = 0
            
        }
    }
}

