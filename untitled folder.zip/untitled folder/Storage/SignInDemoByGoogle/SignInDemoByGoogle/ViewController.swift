//
//  ViewController.swift
//  SignInDemoByGoogle
//
//  Created by Appinventiv on 26/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit
import GoogleSignIn

class ViewController: UIViewController,GIDSignInDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance()?.presentingViewController = self
    }
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if error != nil{
            print(error.debugDescription)
        }else{
            guard let user = user else{ return }
            let userModel = UserModel(email: user.profile.email, name: user.profile.name)
            print(userModel)
            
        }
        
    }
    @IBAction func didtappedLogIn(_ sender: UIButton) {
       GIDSignIn.sharedInstance()?.signIn()
       
    }
    
    @IBAction func logOutButtonTapped(_ sender: Any) {
        GIDSignIn.sharedInstance()?.signOut()
    }
    
}

