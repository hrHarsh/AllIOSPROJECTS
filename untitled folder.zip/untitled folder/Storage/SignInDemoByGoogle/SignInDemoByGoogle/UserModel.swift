//
//  UserModel.swift
//  SignInDemoByGoogle
//
//  Created by Appinventiv on 26/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

struct UserModel{
   
    var email: String
    var name: String
   
}
