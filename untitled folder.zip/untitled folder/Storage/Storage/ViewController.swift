//
//  ViewController.swift
//  Storage
//
//  Created by Appinventiv on 08/10/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var text: UITextField!
    @IBOutlet weak var images:UIImageView!
    
    var userDefaults = UserDefaults.standard
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view.
    }

    @IBAction func saveText(_ sender: UIButton) {
         let image = UIImage(imageLiteralResourceName: "iphone-ios-update-blurred-laptop-pc-background-iphone-ios-update-blurred-laptop-pc-keyboard-background-128686056")
        userDefaults.set(text.text,forKey: "set")
        saveImageToDocumentDirectory(image: image)
    }
    
    @IBAction func loadText(_ sender: UIButton) {
        label.text = userDefaults.string(forKey: "set")
        let image = loadImageFromDocumentDirectory(nameOfImage: "image")
        images.image = image
    }
    func saveImageToDocumentDirectory(image: UIImage ) {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let fileName = "image" // name of the image to be saved
        let fileURL = documentsDirectory.appendingPathComponent(fileName)
        if let data = image.jpegData(compressionQuality: 1.0),!FileManager.default.fileExists(atPath: fileURL.path){
            do {
                try data.write(to: fileURL)
                print("file saved")
            } catch {
                print("error saving file:", error)
            }
        }
    }


    func loadImageFromDocumentDirectory(nameOfImage : String) -> UIImage {
        let nsDocumentDirectory = FileManager.SearchPathDirectory.documentDirectory
        let nsUserDomainMask = FileManager.SearchPathDomainMask.userDomainMask
        let paths = NSSearchPathForDirectoriesInDomains(nsDocumentDirectory, nsUserDomainMask, true)
        if let dirPath = paths.first{
            let imageURL = URL(fileURLWithPath: dirPath).appendingPathComponent(nameOfImage)
            let image    = UIImage(contentsOfFile: imageURL.path)
            return image!
        }
        return UIImage.init(named: "default.png")!
    }
    
}

