//
//  Model.swift
//  taskURLSession
//
//  Created by Appinventiv on 04/10/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

struct Model: Codable{
    var stepNumber: String
    var consultationFee: consultationFee
    var slotData: slotData
}

struct consultationFee: Codable{
    var homeVisit: homeVisit
    var clinicVisit: [clinicVisit]
    var onlineConsultation: [onlineConsultation]
}
struct homeVisit: Codable{
    var amount: Int
    var currencyId: String
}
struct clinicVisit: Codable{
    var type: Int
    var time: Int
    var amount: Int
    var currencyId: String
}
struct onlineConsultation: Codable{
    var type: Int
       var time: Int
       var amount: Int
       var currencyId: String
}
struct slotData: Codable{
    var zero: [obj]
    var one: [obj]
    var two: [obj]
    var three: [obj]
    var four: [obj]
    var five: [obj]
    var six: [obj]
    
    enum CodingKeys: String,CodingKey {
        case zero = "0"
        case one = "1"
        case two = "2"
        case three = "3"
        case four = "4"
        case five = "5"
        case six = "6"
    }
}
struct obj: Codable{
    var startTime: Int
    var endTime: Int
    var serviceType: Int
}






