//
//  EndPoints.swift
//  taskURLSession
//
//  Created by Appinventiv on 05/10/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation
enum Endpoints: String {
    
   case url = "https://apps.flock.co/flock-snippets/snippets/97f9f060-de4d-46b5-a88f-54198022207f/raw"
    
    
}
