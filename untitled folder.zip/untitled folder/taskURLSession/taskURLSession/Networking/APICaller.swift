//
//  APICaller.swift
//  taskURLSession
//
//  Created by Appinventiv on 05/10/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation
final class APICaller {
    
    private init() {}

    
    static func callHelloAPI(param: Model?, callBack:@escaping(_ success: Bool, _ message: String, _ model: Model? )->()) {
        
        Networking.callAPI(url: Endpoints.url.rawValue, param: param) { (err, decodedModel) in
            if err == nil, let model = decodedModel {
                
                //parsing of contact model
//                let c = Model
                let decodedModel = try JSONDecoder().decode(Model.self,from: unwrappedData)
                callBack(true, "Hurrey!", decodedModel)
            } else {
                callBack(false, "Hurrey!", nil)
            }
        }
    }
}
