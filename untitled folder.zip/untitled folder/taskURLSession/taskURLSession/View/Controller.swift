//
//  Controller.swift
//  taskURLSession
//
//  Created by Appinventiv on 05/10/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation


class ConverterController {
    
    enum Slots: String {
        
        case Monday = "0"
        case Tuesday = "1"
        case  Wednesday = "2"
        case  Thursday = "3"
        case  Friday = "4"
        case  Saturday = "5"
        case  Sunday = "6"
    }
   
}

