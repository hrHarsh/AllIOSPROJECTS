//
//  ViewController.swift
//  taskURLSession
//
//  Created by Appinventiv on 04/10/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //MARK:- OUTLETS -
    @IBOutlet weak var shadowView: UIView!
    @IBOutlet weak var amountLabel: UILabel!
    @IBOutlet weak var onlineButton: UIButton!
    @IBOutlet weak var clinicButton: UIButton!
    @IBOutlet weak var homeButton: UIButton!
    
    @IBOutlet weak var timeLabel1: UILabel!
    @IBOutlet weak var timeLabel2: UILabel!
    @IBOutlet weak var timeLabel3: UILabel!
    @IBOutlet weak var timeLabel4:UILabel!
    @IBOutlet weak var weekDay1: UILabel!
    @IBOutlet weak var weekDay2: UILabel!
    @IBOutlet weak var weekday3: UILabel!
    @IBOutlet weak var weekDay4: UILabel!
    //MARK:- PROPERTIES-
    var tapped: String = "online"
    var data: Model?
    //MARK:- View LifeCycle -
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setView()
        self.callAPI()
        
        
    }
    
    func callAPI(){
        guard let jsonURL = URL(string: "https://apps.flock.co/flock-snippets/snippets/97f9f060-de4d-46b5-a88f-54198022207f/raw")else{ return }
        parseJson(url: jsonURL, completionHandler: {
            data -> Void in
            self.data = data
            print(data)
            self.setData(data: data)
            
        })
    }
    
    func setView(){
        shadowView.layer.cornerRadius = 10
        shadowView.layer.shadowColor = UIColor.black.cgColor
        shadowView.layer.shadowOffset = CGSize(width: 0, height: 0)
        shadowView.layer.shadowOpacity = 0.7
        shadowView.layer.shadowRadius = 4.0
    }
    func parseJson(url:URL,completionHandler:@escaping (Model?)-> Void ){
        
        let dataURL = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: dataURL){
            data,response,err in
            guard let unwrappedData = data else { return }
            print(unwrappedData)
            do {
                let dict = try JSONDecoder().decode(Model.self,from: unwrappedData)
                DispatchQueue.main.async {
                    completionHandler(dict)
                }
                //                 print(dict)
            }catch{
                print("Not done")
            }
            
        }
        dataTask.resume()
        
    }
    //MARK:- IBActions -
    @IBAction func onlineConsultationTapped(_ sender: UIButton) {
        tapped = "online"
        setData(data: data)
    }
    
    @IBAction func clinicVisitTapped(_ sender: UIButton) {
        tapped = "clinic"
        setData(data: data)
    }
    
    @IBAction func homeVisitTapped(_ sender: UIButton) {
        tapped = "home"
        setData(data: data)
    }
    //MARK:- PRIVATE FUNCTIONS-
    private func setData(data: Model?){
        switch tapped {
        case "online":
            setOnlineData()
        case "clinic":
            setClinicData()
        case "home":
            setHomeData()
        default:
            return
        }
    }
    
    func setOnlineData(){
        self.amountLabel.text = "\(data?.consultationFee.onlineConsultation[0].amount as! Int)"
        self.timeLabel1.text = "\(data?.consultationFee.onlineConsultation[0].time as! Int)"
    }
    func setHomeData(){
        
        self.amountLabel.text = "\(data?.consultationFee.homeVisit.amount as! Int)"
//        self.timeLabel1.text = "\(data?.consultationFee.homeVisit)"
    }
    func setClinicData(){
        
        self.amountLabel.text = "\(data?.consultationFee.clinicVisit[0].amount as! Int)"
        self.timeLabel1.text = "\(data?.consultationFee.clinicVisit[0].time as! Int)"
    }
}
