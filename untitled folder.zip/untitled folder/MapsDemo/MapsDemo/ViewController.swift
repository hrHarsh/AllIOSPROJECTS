//
//  ViewController.swift
//  MapsDemo
//
//  Created by Appinventiv on 04/10/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController,MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //MARK: - for map point-
        let source = MKPointAnnotation()
        let sourcePin = CLLocationCoordinate2D(latitude: 26.9124, longitude: 75.7873)
        source.coordinate = sourcePin
        source.title = "Jaipur"
        mapView.addAnnotation(source)

        //MARK:- for centre and span-
        let mapCenter = CLLocationCoordinate2D(latitude: 26.9124, longitude: 75.7873)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: mapCenter, span: span)
        mapView.region = region

    }
    
//    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
//        return source
//    }
}

