//
//  DataViewController.swift
//  FaceBookLogin
//
//  Created by Appinventiv on 26/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class DataViewController: UIViewController {

    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var emailIDLabel: UILabel!
    
    var profileData : [String:Any] = ["":""]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        firstNameLabel.text = profileData["first_name"] as? String
        lastNameLabel.text = profileData["last_name"] as? String
        emailIDLabel.text = profileData["email"] as? String
        
    }
    
}
