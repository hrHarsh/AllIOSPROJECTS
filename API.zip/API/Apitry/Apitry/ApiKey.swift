//
//  ApiKey.swift
//  Apitry
//
//  Created by Appinventiv on 21/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation
import UIKit


    enum API: String{
        case hello
        case id
        case title
        
    }

