//
//  ViewController.swift
//  Apitry
//
//  Created by Appinventiv on 21/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        guard let jsonUrl = URL(string:"http://toamaapp.com/api/v1/get-categories") else {
            return
        }
        var dataURL = URLRequest.init(url:jsonUrl)
        dataURL.addValue(HEADER,forHTTPHeaderField: "Authorization")
        let dataTask = URLSession.shared.dataTask(with: dataURL){
            data,response,err in
            
            guard let unwrappedData = data else{ return }
            print(unwrappedData)
            do{
                    let dict = try JSONDecoder().decode(Response.self, from: unwrappedData)
                    print(dict)
                    
                }
                catch let e{
                    print(e)
                }
        }
            dataTask.resume()
        
    }
    
}

