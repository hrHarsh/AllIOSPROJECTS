//
//  model.swift
//  Apitry
//
//  Created by Appinventiv on 21/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation
import UIKit

struct Response: Codable {
    var code: Int
    var message: String
    var result: [CatagoriesModel]?
    
    enum CodingKeys: String, CodingKey {
        case code = "CODE"
        case message = "MESSAGE"
        case result = "RESULT"
    }
}

struct CatagoriesModel: Codable {
    
    let id : Int
    let title: String
//    init(id:Int,title:String) {
//        self.id = id
//        self.title = title
//    }
//    init(dict: JSON) {
//        self.id = dict[API.id.rawValue].intValue
//        self.title = dict[API.title.rawValue].stringValue
//    }
}
//struct Contact :Codable{
//    let hello: String
//
//    init(hello :String) {
//        self.hello = hello
//    }
//}
