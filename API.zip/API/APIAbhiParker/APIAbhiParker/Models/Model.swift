//
//  Model.swift
//  APIAbhiParker
//
//  Created by Appinventiv on 24/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

struct Model: Codable{
    var statusCode: Int
    var message: String
    var data: String
    
    enum CodingKeys: String, CodingKey {
        case statusCode
        case message
        case data
    }
}


