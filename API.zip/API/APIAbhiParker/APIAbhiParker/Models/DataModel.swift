//
//  DataModel.swift
//  APIAbhiParker
//
//  Created by Appinventiv on 25/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

struct DataModel: Codable {
    var statusCode: Int
    var message: String
    var data: Profile?
}
struct Profile: Codable {
    var profile_pic:String
    var name: String
    var email: String
}
//{
//    "statusCode": 200,
//    "message": "Successfully retrived",
//    "data": {
//        "profile_pic": "https://images-cdn.9gag.com/photo/5486312_700b.jpg",
//        "name": "harsh",
//        "email": "bhodu@gmail.com"
//    }
