//
//  ViewController.swift
//  APIAbhiParker
//
//  Created by Appinventiv on 24/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordtextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
}
       //MARK:- POSTAPI-
    @IBAction func postAPI(_ sender: UIButton) {
        let json: [String: String] = ["name": nameTextField.text!, "email":emailTextField.text!, "password":passwordtextField.text!]
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        guard let url = URL(string: "https://abhiparker.herokuapp.com/user/login") else{ return }
        var request = URLRequest(url: url)
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        request.httpBody = jsonData
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let unwrappedData = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            guard let responseJSON = try? JSONDecoder().decode(Model.self, from: unwrappedData) else{ return }
            print(responseJSON)
            HEADER = "Bearer \(responseJSON.data)"
            self.getAPI()
            print(HEADER)
        }
        task.resume()
    }
    
 

//MARK:-GET API-
func getAPI(){
    guard let jsonURL = URL(string: "https://abhiparker.herokuapp.com/user")else{ return }
    var dataURL = URLRequest(url: jsonURL)
   dataURL.addValue(HEADER, forHTTPHeaderField: "Authorization")
    let dataTask = URLSession.shared.dataTask(with: dataURL){
        data,response,err in
        guard let unwrappedData = data else { return }
        print(unwrappedData)
        do {
            let dict = try JSONDecoder().decode(DataModel.self,from: unwrappedData)
            
           self.showProfileViewController(dict: dict)
        }catch{
            print("Not done")
        }
    }
    dataTask.resume()
        }
    
    func showProfileViewController(dict: DataModel) {
        DispatchQueue.main.async {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
            vc.data = dict
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}

