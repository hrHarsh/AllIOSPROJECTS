//
//  ProfileViewController.swift
//  APIAbhiParker
//
//  Created by Appinventiv on 25/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    var data: DataModel?
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        setValues()
        // Do any additional setup after loading the view.
    }
    func setValues(){
        nameLabel.text = data?.data?.name
        emailLabel.text = data?.data?.email
        guard let url = URL(string:((data?.data!.profile_pic)!)) else{ return }
        let image = try? Data(contentsOf: url)
        images.image = UIImage(data: image!)
    }
}
