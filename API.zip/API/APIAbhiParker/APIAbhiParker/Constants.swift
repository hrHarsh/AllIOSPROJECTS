//
//  Constants.swift
//  APIAbhiParker
//
//  Created by Appinventiv on 24/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

var HEADER = ""
