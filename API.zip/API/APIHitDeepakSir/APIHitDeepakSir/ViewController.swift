//
//  ViewController.swift
//  APIHitDeepakSir
//
//  Created by Appinventiv on 24/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var model: [Container] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let jsonURL = URL(string: "http://toamaapp.com/api/v1/search-posts?search_name=a")else{ return }
        var dataURL = URLRequest(url: jsonURL)
        dataURL.addValue(HEADER, forHTTPHeaderField: "Authorization")
        let dataTask = URLSession.shared.dataTask(with: dataURL){
            data,response,err in
            guard let unwrappedData = data else { return }
            print(unwrappedData)
            do {
                let dict = try JSONDecoder().decode(Container.self,from: unwrappedData)
                print(dict)
                self.model = [dict]
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }catch{
            print("Not done")
            }
        }
        dataTask.resume()
    }
}

extension ViewController:UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.setupCell(model[indexPath.row])
        return cell
    }
    
    
}
