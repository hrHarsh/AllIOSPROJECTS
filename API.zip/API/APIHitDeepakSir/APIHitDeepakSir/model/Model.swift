//
//  Model.swift
//  APIHitDeepakSir
//
//  Created by Appinventiv on 24/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

struct Container: Codable{
    var code: Int
    var message: String
    var result: Category?
    
    enum CodingKeys: String, CodingKey{
        case code = "CODE"
        case message = "MESSAGE"
        case result = "RESULT"
    }
}
struct Category: Codable{
    var currentPage: Int
    var data: [DataModel]?
    var firstPageURL: String?
    var from: Int
    var lastPage: Int
    var lastPageURL: String?
    var nextPageURL: String?
    var path: String
    var perPage: Int
    var previousPageURL: String?
    var to: Int
    var total: Int
    enum CodingKeys: String, CodingKey{
        case currentPage = "current_page"
        case data
        case firstPageURL = "first_page_url"
        case from
        case lastPage = "last_page"
        case lastPageURL = "last_page_url"
        case nextPageURL = "next_page_url"
        case path
        case perPage = "per_page"
        case previousPageURL = "prev_page_url"
        case to
        case total
    }
}
struct DataModel: Codable{
    
    var id: Int
    var name: String
    var endDate:String
    var createdAt: String
    var endDateTimestamp: Double
    var createdAtTimestamp:Double
    var images: [Images]?
    
    enum CodingKeys: String, CodingKey{
        case id
        case name
        case endDate = "end_date"
        case createdAt = "created_at"
        case endDateTimestamp = "end_date_timestamp"
        case createdAtTimestamp = "created_at_timestamp"
        case images
    }
}

struct Images: Codable {
    var image: String
    
    enum CodingKeys: String, CodingKey{
        case image
    }
}
