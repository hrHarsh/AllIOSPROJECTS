//
//  TableViewCell.swift
//  APIHitDeepakSir
//
//  Created by Appinventiv on 24/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var imageOutlet: UIImageView!
    @IBOutlet weak var label: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setupCell(_ model: Container){
        self.label.text = "\(model.result?.currentPage ?? 0)"
        
    }
    

}
