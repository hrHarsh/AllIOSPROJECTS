//
//  ViewController.swift
//  AppleMaps
//
//  Created by Appinventiv on 27/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit
import MapKit


class ViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    var sourceCordinate = (0.0,0.0)
    var destinationCoordinate = (0.0,0.0)
    var locInfo = ("","")
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
     
}
    func setup(){
        let sourceDirection = CLLocationCoordinate2D(latitude: sourceCordinate.0, longitude: sourceCordinate.1)
        let destinationDirection = CLLocationCoordinate2D(latitude: destinationCoordinate.0, longitude: destinationCoordinate.1)
        let sourcePin = CustomPin(pinTitle: "\(locInfo.0)", pinSubTitle: "Source", location: sourceDirection)
        let destinationPin = CustomPin(pinTitle: "\(locInfo.1)", pinSubTitle: "Destination", location: destinationDirection)
                self.mapView.addAnnotation(sourcePin)
                self.mapView.addAnnotation(destinationPin)
                
                let sourcePlacemark = MKPlacemark(coordinate: sourceDirection)
                let destinationPlacemark = MKPlacemark(coordinate: destinationDirection)
                let directionRequest = MKDirections.Request()
                directionRequest.source = MKMapItem(placemark: sourcePlacemark)
                directionRequest.destination = MKMapItem(placemark: destinationPlacemark)
                directionRequest.transportType = .any
        
                let directions = MKDirections(request: directionRequest)
                directions.calculate {  (response,error) in
                    guard let directionResponse = response  else {
                        if let error = error{
                            print(error.localizedDescription)
                        }
                        return
                    }
                    
                    let route = directionResponse.routes[0]
                    self.mapView.addOverlay(route.polyline,level: .aboveRoads)
                    let rect = route.polyline.boundingMapRect
                    self.mapView.setRegion(MKCoordinateRegion(rect), animated: true)
                }
    }
    //MARK:- IBACTIONS-
    @IBAction func mapTypeSelection(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            self.mapView.mapType = .mutedStandard
        case 1:
            self.mapView.mapType = .satelliteFlyover
        default:
            self.mapView.mapType = .hybrid
        }
    }
    
   
}

extension ViewController:MKMapViewDelegate{
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = .blue
        renderer.lineWidth = 5
        return renderer
    }
    
}
