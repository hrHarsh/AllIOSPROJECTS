//
//  UserViewController.swift
//  AppleMaps
//
//  Created by Appinventiv on 30/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit
import CoreLocation

typealias callback = (_ location:CLLocation)->()

class UserViewController: UIViewController {

//MARK:- Properties-
    @IBOutlet weak var sourceTextField: UITextField!
    @IBOutlet weak var destinationTextField: UITextField!
    @IBOutlet weak var sourceStackView: UIStackView!
    @IBOutlet weak var destinationStackView: UIStackView!
    @IBOutlet weak var doneButton: UIButton!
    @IBOutlet var submitButton: UIView!
    let geocoder = CLGeocoder()
    
//MARK:- Variables-
    var sourceCoordinate = CLLocationCoordinate2D()
    var destinationCoordinate = CLLocationCoordinate2D()
    override func viewDidLoad() {
        super.viewDidLoad()
        destinationStackView.isHidden = true
        submitButton.isHidden = true
    }
    @IBAction func didTappedSubmitButton(_ sender: UIButton) {
        let address = destinationTextField.text ?? ""
        self.getLocation(address: address){
            location in
            self.destinationCoordinate = location.coordinate
            if #available(iOS 13.0, *) {
                let vc = self.storyboard?.instantiateViewController(identifier: "ViewController") as! ViewController
                vc.locInfo = (self.sourceTextField.text, self.destinationTextField.text) as! (String, String)
                vc.sourceCordinate = (self.sourceCoordinate.latitude,self.sourceCoordinate.longitude)
                vc.destinationCoordinate = (self.destinationCoordinate.latitude,self.destinationCoordinate.longitude)
                       self.navigationController?.pushViewController(vc, animated: true)
            } else {
                // Fallback on earlier versions
            }
        }
        print(destinationCoordinate)
        
    }
    @IBAction func didtappedDoneButton(_ sender: UIButton) {
       let address = sourceTextField.text ?? ""
        getLocation(address: address){location in
            self.sourceCoordinate = location.coordinate
            print(self.sourceCoordinate)
            self.doneButton.isHidden = true
            self.destinationStackView.isHidden = false
            self.submitButton.isHidden=false
            self.sourceStackView.isHidden = true
        }
    }
    
    func getLocation(address: String,callback: @escaping callback ) {
        var location: CLLocation?
        self.geocoder.geocodeAddressString(address, completionHandler: {(placemarks, error) -> Void in
            if((error) != nil){
                print("Error", error ?? "")
                return
            }
            if (placemarks?.first) != nil {
                location = placemarks?.first?.location
                callback(location ?? CLLocation())
            }})
    }
}
