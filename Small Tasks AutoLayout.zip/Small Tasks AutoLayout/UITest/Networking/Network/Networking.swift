//
//  Networking.swift
//  UITest
//
//  Created by Appinventiv on 18/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

typealias JSONDictionary = [String: Any]
typealias JSONArray = [JSONDictionary]
typealias CallBack = (_ err: Error?, _ dict: JSONDictionary?)->()

final class Networking {
    
    private init() { }
    
    static func callAPI(url: String, param: JSONDictionary, header: JSONDictionary = [:], callBack:@escaping CallBack) {

        guard let url = URL(string: url) else {
            callBack(NetworkError.somethinWentWrong, param)
            return
        }
        
        var req = URLRequest.init(url: url)
        req.addValue("Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjRkNTNiN2IzMzQ4YTdhNWM4MDFhOGQ1ZjBmOTZlOWVjMjIxNzE5NmM3ZTZhMzA2MzlhNDZlZmYzNmZhZDc4YzUyYmNiZTE3MTAzMTQ2NmFmIn0.eyJhdWQiOiIxIiwianRpIjoiNGQ1M2I3YjMzNDhhN2E1YzgwMWE4ZDVmMGY5NmU5ZWMyMjE3MTk2YzdlNmEzMDYzOWE0NmVmZjM2ZmFkNzhjNTJiY2JlMTcxMDMxNDY2YWYiLCJpYXQiOjE1Njg2MTgzNDgsIm5iZiI6MTU2ODYxODM0OCwiZXhwIjoxNjAwMjQwNzQ4LCJzdWIiOiI2OSIsInNjb3BlcyI6W119.TZdi_7xb-rwsIVufPcJVc4CVYqI0MypEvHbyFqfNQgL9WpXHbzbU1N3vtv6kWK1HE08NeaZd1aQws7YNwpdUK3pXnTW4K1UtUko6K2ty-F6Hi6fkwir-Kka2SYwwaEe7ng90Kt0Rzv_YMr9SB1_1Q7NWFZZDq1JMJWlvT-X4dX-ybBIZY44_D__BnAOPBL5-LZ_8Fojogb4EfyBhXqFBGLpG9ncfuM78ih1To-5dcqwQm5RBpsN6R3BooauaQ2OS7URqcbjXYCKjS4fKgU-zXrxJcGP4jr-VJis-nhtZWTG0UQUKjX9qur-NYnc398pbasUTOMfRDy_nD--Km0UPo60e-cJ6mxwuK9wYrDaW9Y8IzgfKcKMflWvygHsD1cXqR1F7yURR9UMLQomN-40cljFJ9j_o4qs2ilhmqnO1DFaQdeWC84hUizJsw7RWpaqfiM1uOn7XuYtCo11uuvYOMPceBTsvJjXrXrPHMFSeKy2HOu-7bNxe4xC-DchG3d-cUtTM9rSQCNjsmJmLJ8Wn5KaeuKEqp-oXtLrCp4QgzOd1nVAMLjEcuMvaUvNuGG6CGBV7IyKp98Nt-by2HaMzSmHmM-ABRQN31uSU1nGMqnBDuACKTn5dKcO7caEdw559YEa5hJGxCrv8CtEjVC64yZ5GPxTeY3H_d2qADJK4gpI", forHTTPHeaderField: "Authorization")
//        print(req)
        let dataTask = URLSession.shared.dataTask(with: req) { (data,response,err) in
//            print(req)
            guard let unwrappedData = data else {
                callBack(err,param)
                return
            }
            do {
                let dict = try JSONSerialization.jsonObject(with: unwrappedData, options : .allowFragments) as? JSONDictionary
                callBack(err, dict)
            } catch let e {
                callBack(e, nil)
            }
        }
        dataTask.resume()
    }
}
extension Networking {
    var header: String {
        return "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjRkNTNiN2IzMzQ4YTdhNWM4MDFhOGQ1ZjBmOTZlOWVjMjIxNzE5NmM3ZTZhMzA2MzlhNDZlZmYzNmZhZDc4YzUyYmNiZTE3MTAzMTQ2NmFmIn0.eyJhdWQiOiIxIiwianRpIjoiNGQ1M2I3YjMzNDhhN2E1YzgwMWE4ZDVmMGY5NmU5ZWMyMjE3MTk2YzdlNmEzMDYzOWE0NmVmZjM2ZmFkNzhjNTJiY2JlMTcxMDMxNDY2YWYiLCJpYXQiOjE1Njg2MTgzNDgsIm5iZiI6MTU2ODYxODM0OCwiZXhwIjoxNjAwMjQwNzQ4LCJzdWIiOiI2OSIsInNjb3BlcyI6W119.TZdi_7xb-rwsIVufPcJVc4CVYqI0MypEvHbyFqfNQgL9WpXHbzbU1N3vtv6kWK1HE08NeaZd1aQws7YNwpdUK3pXnTW4K1UtUko6K2ty-F6Hi6fkwir-Kka2SYwwaEe7ng90Kt0Rzv_YMr9SB1_1Q7NWFZZDq1JMJWlvT-X4dX-ybBIZY44_D__BnAOPBL5-LZ_8Fojogb4EfyBhXqFBGLpG9ncfuM78ih1To-5dcqwQm5RBpsN6R3BooauaQ2OS7URqcbjXYCKjS4fKgU-zXrxJcGP4jr-VJis-nhtZWTG0UQUKjX9qur-NYnc398pbasUTOMfRDy_nD--Km0UPo60e-cJ6mxwuK9wYrDaW9Y8IzgfKcKMflWvygHsD1cXqR1F7yURR9UMLQomN-40cljFJ9j_o4qs2ilhmqnO1DFaQdeWC84hUizJsw7RWpaqfiM1uOn7XuYtCo11uuvYOMPceBTsvJjXrXrPHMFSeKy2HOu-7bNxe4xC-DchG3d-cUtTM9rSQCNjsmJmLJ8Wn5KaeuKEqp-oXtLrCp4QgzOd1nVAMLjEcuMvaUvNuGG6CGBV7IyKp98Nt-by2HaMzSmHmM-ABRQN31uSU1nGMqnBDuACKTn5dKcO7caEdw559YEa5hJGxCrv8CtEjVC64yZ5GPxTeY3H_d2qADJK4gpI"
    }
}

enum NetworkError: Error {
    case somethinWentWrong
    case notReachable
    case someError
    
    var localizedDescription: String {
        switch self {
        case .someError: return "Error occured!"
        case .somethinWentWrong: return "Something went wrong..."
        case .notReachable: return "Not reachable"
        }
    }
}


