//
//  ConverterController.swift
//  Networking
//
//  Created by Appinventiv on 18/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

protocol ConverterControllerProtocol: class {
    func willHitAPI()
    func apiHitSuccessFul(messages: String)
    func apiHitFail(message: String)
}

class ConverterController {
    
    weak var delegate: ConverterControllerProtocol?
    
    private(set) var categoryList: [CatagoriesModel] = []
    
    func testAPICall() {
        
        self.delegate?.willHitAPI()
        
//        APICaller.callHelloAPI(url: Endpoints.helloUrl.rawValue, param: [:] ) {[weak self] (success, message, contactModel) in
//
//            guard let self = self else {
//                return }
//            print(success, message, contactModel)
//            if success, let c = contactModel {
//                self.contact = c
//                self.delegate?.apiHitSuccessFul(messages: message)
//            } else {
//                self.delegate?.apiHitFail(message: message)
//            }
//        }
        
        APICaller.callCategoriesAPI(url: Endpoints.categories.rawValue, param: [:], header: ["Authorization":"Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6IjRkNTNiN2IzMzQ4YTdhNWM4MDFhOGQ1ZjBmOTZlOWVjMjIxNzE5NmM3ZTZhMzA2MzlhNDZlZmYzNmZhZDc4YzUyYmNiZTE3MTAzMTQ2NmFmIn0.eyJhdWQiOiIxIiwianRpIjoiNGQ1M2I3YjMzNDhhN2E1YzgwMWE4ZDVmMGY5NmU5ZWMyMjE3MTk2YzdlNmEzMDYzOWE0NmVmZjM2ZmFkNzhjNTJiY2JlMTcxMDMxNDY2YWYiLCJpYXQiOjE1Njg2MTgzNDgsIm5iZiI6MTU2ODYxODM0OCwiZXhwIjoxNjAwMjQwNzQ4LCJzdWIiOiI2OSIsInNjb3BlcyI6W119.TZdi_7xb-rwsIVufPcJVc4CVYqI0MypEvHbyFqfNQgL9WpXHbzbU1N3vtv6kWK1HE08NeaZd1aQws7YNwpdUK3pXnTW4K1UtUko6K2ty-F6Hi6fkwir-Kka2SYwwaEe7ng90Kt0Rzv_YMr9SB1_1Q7NWFZZDq1JMJWlvT-X4dX-ybBIZY44_D__BnAOPBL5-LZ_8Fojogb4EfyBhXqFBGLpG9ncfuM78ih1To-5dcqwQm5RBpsN6R3BooauaQ2OS7URqcbjXYCKjS4fKgU-zXrxJcGP4jr-VJis-nhtZWTG0UQUKjX9qur-NYnc398pbasUTOMfRDy_nD--Km0UPo60e-cJ6mxwuK9wYrDaW9Y8IzgfKcKMflWvygHsD1cXqR1F7yURR9UMLQomN-40cljFJ9j_o4qs2ilhmqnO1DFaQdeWC84hUizJsw7RWpaqfiM1uOn7XuYtCo11uuvYOMPceBTsvJjXrXrPHMFSeKy2HOu-7bNxe4xC-DchG3d-cUtTM9rSQCNjsmJmLJ8Wn5KaeuKEqp-oXtLrCp4QgzOd1nVAMLjEcuMvaUvNuGG6CGBV7IyKp98Nt-by2HaMzSmHmM-ABRQN31uSU1nGMqnBDuACKTn5dKcO7caEdw559YEa5hJGxCrv8CtEjVC64yZ5GPxTeY3H_d2qADJK4gpI"]) {[weak self] (success, message, catList) in

            guard let self = self else {
                return }
//            print(success, message, categoryModel)
            if success, let catList = catList {
                self.categoryList = catList
                self.delegate?.apiHitSuccessFul(messages: message)
            } else {
                self.delegate?.apiHitFail(message: message)
            }
        }
//
        }
    
}




