//
//  ConverterViewController.swift
//  UITest
//
//  Created by Appinventiv on 26/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ConverterViewController : BaseVC {
    
    private let controller = ConverterController()
    
    @IBOutlet private weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.controller.testAPICall()
        
    }
    
    override func bindController() {
        self.controller.delegate = self
    }
}

extension ConverterViewController: ConverterControllerProtocol {
    
    func willHitAPI() {
        //Show loader
        print("API will Hit")
    }
    
    func apiHitSuccessFul(messages: String) {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func apiHitFail(message: String) {
        //Snakbar or toast message
        print("API failed")
    }
    
    
}
//MARK:- TableView Datasource functions-
extension ConverterViewController: UITableViewDataSource{

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.controller.categoryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        
        cell.configCell(cat: self.controller.categoryList[indexPath.row])
        return cell
    }
}

