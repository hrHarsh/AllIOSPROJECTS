//
//  TableViewCell.swift
//  Networking
//
//  Created by Appinventiv on 20/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var idLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configCell(cat: CatagoriesModel) {
        self.titleLabel.text = cat.title
        self.idLabel.text = "\(cat.id)"
    }

}
