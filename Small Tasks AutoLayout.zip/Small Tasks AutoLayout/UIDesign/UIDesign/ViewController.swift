//
//  ViewController.swift
//  UIDesign
//
//  Created by Appinventiv on 10/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func SendData(_ sender: Any) {
      let vc = self.storyboard?.instantiateViewController(withIdentifier: "DataReceiver") as! DataReceiver
        vc.email=Email.text!
        vc.password=Password.text!
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

