//
//  DataReceiver.swift
//  UIDesign
//
//  Created by Appinventiv on 10/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation
import UIKit

class DataReceiver: UIViewController{
    var email=String()
    var password=String()
    
    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var Label2: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Label.text=email
        Label2.text=password
    }
    
}
