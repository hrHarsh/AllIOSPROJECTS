
class MultipleDuplicate{
    var number=[5,4,5,4,3,4,7,7,7,7,7,7,7]
    func find(){
        var check = [Int]()
        
        for i in 0..<number.count{
            for j in (i+1)..<number.count{
                if(number[i]==number[j]){
                    if(check.contains(number[i])){
                        continue
                    }
                    else{
                        check.append(number[i])
                    }
                }
            }
        }
        
        print(check)
        
    }
}
var multipleduplicate = MultipleDuplicate()
multipleduplicate.find()
