import UIKit

var gcf=[12,20,36]
var small=gcf[0]
var hcf=0,count=0
var j=1
for i in 2...small{
    count=0
    for j in 0..<gcf.count{
        if(gcf[j]%i == 0){
            count+=1
        }
    }
    if(count==gcf.count){
        hcf=i
    }
}
print(hcf)
