import UIKit
var odd=1,k=0,n=4
for _ in 1...4{
    for _ in 1...n{
        print(" ",terminator:"")
    }
    for j in 1...odd{
        let middle=odd/2+1
        if(j<=middle){
            k+=1
        }
        else{
            k-=1
        }
        print("\(k)",terminator:"")
    }
    odd+=2
    n-=1
    print()
}
