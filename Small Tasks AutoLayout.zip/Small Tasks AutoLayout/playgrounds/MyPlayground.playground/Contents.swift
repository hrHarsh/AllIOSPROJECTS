import UIKit
//func removeandInsert(str:String)->String{
//    var newWord=str
//    var index=newWord.index(before:newWord.endIndex)
//    var add=newWord[index]
//    newWord.insert(add, at: newWord.startIndex)
//
//    return newWord
//}
//print(removeandInsert(str:"hello"))
//func add(str:String){
//    var newWord=str
//    let new=String(str[str.startIndex])+String(str[str.index(after:str.startIndex)])
//    print(new)
//    newWord.insert(contentsOf:new, at: newWord.endIndex)
//    newWord.insert(contentsOf:new, at: newWord.startIndex)
//    print(newWord)
//
//}
//add(str: "hello")
//func check(str:String)->Bool{
//    var new=str
//    new.remove(at: new.startIndex)
//    if(new.hasPrefix("ix")){
//        return true
//    }
//    else{
//        return false
//    }
//
//}
//print(check(str: "sixer"))
//func largethree(a:Int,b:Int,c:Int)->Int{
//    if(a>b&&a>c){
//        return a
//    }
//    else if(b>c&&b>a){
//        return b
//    }
//    else{
//        return c
//    }
//}
//print(largethree(a: 5, b: 11, c: 9))
//var str="abcde"
//var count=str.count
//if(count<3)
//{
//    print(str.lowercased())
//}
//else if(count>=3){
//let up=str.index(str.endIndex,offsetBy: -3)..<str.endIndex
//var a=str[up].uppercased()
//print(a)
//}
//func consecutivea(_ str:String) -> Bool{
//
//    var arr  =  Array(str)
//    for i in 0...str.count-1{
////        print(str[i] ,terminator: "" )      PUCHNA H
////        print(arr[i],terminator: "")
//        if(arr[i]=="a" && arr[i+1]=="a")
//        {
//            return true
//        }
//
//    }             offset,enumerated
//
//    return false
//
//}
//print(consecutivea("hgjdhskh"))
//var str  = "jbdjbsjbhaas"
//var sindex = str.startIndex       puchn H
//var eindex = str.endIndex
//var mrange  = sindex..<eindex
//var substring = str.substring(to: mrange)
//
//var ss="asdf;lkj"
//var count=1
//while count<ss.count{
//    ss.remove(at: ss.index(ss.startIndex,offsetBy:count))
//    count+=1
//}
//print(ss, terminator: "")
//
//var first="star"
//var second="with"
//let middle=(first.count)/2
//first.insert(contentsOf:second, at:first.index(first.startIndex, offsetBy:middle))
//print(first)
// var str="hello"
//var copy=str[str.index(str.endIndex,offsetBy: -2)..<str.endIndex]
//print(copy)
//var a="strlin"
//print(a[a.index(a.startIndex, offsetBy: (a.count/2)-1 )...a.index(a.startIndex, offsetBy: a.count/2)])
//var str="Swift"
//var first=str[str.index(str.startIndex, offsetBy: 0)..<str.index(str.startIndex, offsetBy: 2)]
//print(first)
//var second=str[str.index(str.endIndex,offsetBy:-2)..<str.endIndex]
//print(second)
//var final=first+second
//print(final)
//
//print(str.prefix(2)+str.suffix(2))
//var str="middle"
//var length=str.count/2
//var middl=str[str.index(str.startIndex, offsetBy: length-1)..<str.index(str.startIndex, offsetBy:length+1 )]
//print(middl)
//
//var n=121,rem=0,rev=0
//while n != 0 {
//    rem=n%10
//    rev=rev*10+rem
//    n/=10
//}
//print(rev)

//var n=13;
//var i=n-1
//while i<n{
//    i=i-1
//    if(n%i==0)
//    {
//        break;
//    }
//}
//if(i==1)
//{
//    print("prime")
//}
//else{
//    print("not prime")
//}
//var five=[Int]()
//five.append(contentsOf:[5,6,7,8,8,9])
////five.append(6)
////five.append(7)
//
//if(five[0]==5||five[five.count-1]==5){
//     print(true)
//}
//else{
//    print(false)
//}
//print(five)
//var arr=[1,2,3]
//var a=arr
//a.removeFirst()
//a.append(arr.first!)
////print(a)
//var arr=[3,5,7,9,1]
//var j=arr.count-1
//var temp=0
//for i in 0..<arr.count/2{
//    temp=arr[i]
//    arr[i]=arr[j]
//    arr[j]=temp
//    j-=1
//}
//print(arr)
//var arr=[Int]()
//arr.append(contentsOf:[5,6,7,8,9])
//for i in 0..<arr.count/2{
//    arr.swapAt(i,arr.count-i-1 )
//}
////print(arr)
//var arr=[1,4,5,2,6,7,2]
//var max=arr[0]
//for i in 1..<arr.count{
//    if(max<arr[i]){
//        max=arr[i]
//    }
//}
//print(max)
//for i in 0..<arr.count{
//    arr[i]=max
//}
//print(arr)
//var arr=[3,6,1,7,9,12,45]
//var first=arr[0],second=0,third=0
//
//for i in 0..<arr.count{
//    if(first<arr[i]){
//        third=second
//        second=first
//        first=arr[i]
//    }
//    else if(second<arr[i]&&second != first){
//        third=second
//        second=arr[i]
//    }
//    else if(third<arr[i]&&third != second){
//        third=arr[i]
//    }
//}
//var least=first,least2=0,least3=0
//for i in 0..<arr.count{
//    if(least>arr[i]){
//        least3=least2
//        least2=least
//        least=arr[i]
//    }
//    else if(least2>arr[i]&&least2 != least){
//        least3=least2
//        least2=arr[i]
//    }
//    else if(least3>arr[i]&&least3 != least2){
//        least3=arr[i]
//    }
//}
//print("Third largest number=" ,third)
//print("Third smallest number=",least3)
//var arr=[2,4,5,6,1,8,3]
//arr.sort()
//print("Third minimum",arr[arr.count-3])
//print("Third largest",arr[2])
// Missing number
//var arr=[50,51,52,54,55,56]
//for i in 1..<arr.count{
//    if(arr[i-1]+1==(arr[i]))
//    {
//
//    }
//    else {
//        print(arr[i]-1)
//    }
//}
//var arm=370,rev=0,rem=0
//var n=arm
//while arm != 0{
//    rem=arm%10
//    rev=rev+(rem*rem*rem)
//    arm/=10
//}
//if(n==rev){
//    print("Armstrong number")
//}
//else{
//    print("Not armstrong number")
//}
//prime number in a given range
//for i in 1...100{
//    var j=2
//    while j<=i-1{
//        if(i%j==0)
//        {
//            break
//        }
//        j=j+1
//    }
//    if(j==i){
//        print(i)
//    }
//}

//for i in 1...5{
//    for j in (1...5).reversed(){
//        if(i>=j){
//            print(" *",terminator: "")
//        }
//        else{
//            print(" ",terminator: "")
//        }
//    }
//    print()
//}
//print(" ",terminator:"")

//
//let numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
//for (animalName, legCount) in numberOfLegs {
//    print("\(animalName)s have \(legCount) legs")
//}
//Maps
//
//var arr=["Hello","Chlo","Hlo","klo","jlo"]
//var fact=arr.map{$0}
//print(fact)
//
//func multiply(num1:Double , num2:Double) ->Double {
//    var c = 1
//    print("in multiply",c," and the arguments are:",num1,num2)
//    c+=1
//
//    return num1 * num2
//}
//func addition (num1 : Double , num2 : Double ) -> Double
//{   var c = 1
//
//    print("in addition",c," and the arguments are:",num1,num2)
//    c+=1
//    return num1 + num2
//}
//func domathoperations( operation:(_ hvh:Double , _ cvgg:Double)->Double , num1:Double , num2:Double) ->Double
//{
//    print("in do math")
//    var b = operation(num1,num2)
//    print("after ")
//    return b
//}
//
//print(domathoperations(operation:multiply , num1: 10, num2: 2))
//print(domathoperations(operation:addition , num1: 10, num2: 2))

//func asas(a:String,b:String)->Int{
//    print("Int int")
//    return (a.count+b.count)
//}
//func saas(a:String,b:String)->String{
//    print("In string")
//    var c=a,d=b
//
//    return c+d
//}
//func main(operate:(_ a:String,_ b:String)->Int,c:String,d:String)->String{
//    print("In main")
//    return operate(c,d)
//}
//print(main(operate:asas,c:"AAA",d:"BBB"))
//var names=["Ashish","Harsh","Vishal"]
//var reversednames=names.sorted(by: { (_s1:String,_s2:String)->Bool in
//        return _s1 > _s2
//    })
//var reversednames=names.sorted(by:{s1,s2 in s1>s2})
//
//var reversednames=names.sorted(by:{$0>$1})
//var reversednames=names.sorted(by: >)
//print(reversednames)
//var digits=[1:"one",2:"two",3:"three",4:"four",5:"five",6:"six",7:"seven",8:"eight",9:"nine"]
//var numbers=[5,45,231]
//var show=numbers.map{(number) -> String in
//    var number=number
//    var ut = ""
//    repeat{
//        ut=digits[number % 10]! + ut
//        number/=10
//    }while(number > 0)
//    return ut
//}
////print(show)
//
//func prime(a:Int,b:inout Int) {
//    if(b>=2){
//        if(a%b==0){
//            return
//        }
//        else{
//            b-=1
//            prime(a: a, b: &b)
//        }
//    }
//    return
//}
//var a=5
//var b=a-1
// prime(a: a, b: &b)
//if(b==1){
//print("\(a) Prime number",b)
//}
//else {
//    print("\(a) Not a prime number \(b)")
//}
//var odd=1,k=0,n=4
//for _ in 1...4{
//    for _ in 1...n{
//        print(" ",terminator:"")
//    }
//    for j in 1...odd{
//        let middle=odd/2+1
//        if(j<=middle){
//            k+=1
//        }
//        else{
//            k-=1
//        }
//        print("\(k)",terminator:"")
//    }
//    odd+=2
//    n-=1
//    print()
//}
//func single(for str:String) -> String {
//    "Hello"
//}
//func double(argumentLabel ho:String,from asd:String)->String{
//    return "Hello"+ho+asd
//}
//print(single(for: "Dev"))
//print(double(argumentLabel: "jjkj",from: "utt"))
//func para(some:Int,notsome:Int=12){
//    print(some+notsome)
//}
//para(some: 12,notsome: 1)
//enum bev:CaseIterable{
//    case c,t,a
//}
//let nmc=bev.allCases
//print(nmc)
//struct FixedLengthRange {
//    var firstValue: Int
//    let length: Int
//
//}
//var rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
//// the range represents integer values 0, 1, and 2
//print(rangeOfThreeItems)
//rangeOfThreeItems.firstValue = 6
//print(rangeOfThreeItems)
//struct Point{
//    var x=0.0
//    var y=0.0
//}
//struct Size {
//    var width=0.0
//    var height = 0.0
//
//}
//struct Rectangle {
//    var origin=Point()
//    var size=Size()
//    var centre: Point {
//        get{
//            let centreX=origin.x+(size.width/2)
//            let centreY=origin.y+(size.height/2)
//            return Point(x: centreX, y: centreY)
//        }
//        set(newCenter){
//            origin.x = newCenter.x-(size.width/2)
//            origin.y = newCenter.y-(size.height/2)
//
//        }
//    }
//}
//
//var square = Rectangle(origin: Point(x:0.0,y:0.0), size: Size(width:10.0,height:10.0))
//let initial=square.centre
//square.centre=Point(x:15.0,y: 15.0)
//print("square origin is \(square.origin.x) and \(square.origin.y)")
//struct cuboid{
//    var len=0.0,wid=0.0,height=0.0
//    var volume : Double{
//        return len*wid*height
//    }
//}
//let cucall=cuboid(len: 5.0, wid: 3.0, height: 4.0)
//print("Cuboid volume = \(cucall.volume)")
//class StepCounter{
//    var totalsteps:Int=0{
//    willSet(newValue){
//            print("About to set total steps to \(newValue)")
//        }
//        didSet{
//            if totalsteps>oldValue
//            {
//                print("Added \(totalsteps-oldValue) steps")
//            }
//        }
//    }
//}
//var firstcall=StepCounter()
//firstcall.totalsteps=1200
//firstcall.totalsteps=1321
//class call{
//    var closure:[()->Void]=[]
//    func closureFunction(close:@escaping ()->Void){
//        print(closure)
//        closure.append(close)
//        print(closure)
//
//    }
//}
//class toCall{
//    var c=call()
//    var value=10
//    func calltheFunction(){
//        c.closureFunction {
//            self.value=10
//        }
//    }
//}
//let inst=toCall()
//inst.calltheFunction()
//print(inst.value)

//func armstrongNumber(n: inout Int,rem: inout Int,rev:inout Int){
//
//    if(n != 0){
//        rem=n%10
//
//        rev=rev+(rem*rem*rem)
//        n/=10
//        armstrongNumber(n: &n,rem: &rem,rev: &rev)
//    }
//    else{
//        return
//    }
//}
//var arm=371,rem=0,rev=0
//var n=arm,m=arm
//armstrongNumber(n: &n, rem: &rem, rev: &rev)
//if(arm==rev){
//    print("Armstrong number")
//}
//else{
//    print("Not armstrong number")
//}
//var arm=370,rev=0,rem=0
//var n=arm
//repeat{
//    rem=n%10
//    rev = rev+Int(pow(Double(rem), 3))
//    n/=10
//}while(n != 0)
//if(arm==rev){
//    print("\(arm) is an armstrong number")
//}
//else{
//    print("\(arm) is not an armstrong number")
//}
//var height=[5,3,2,6,1,4]
//var InFront=[0,1,2,0,3,2]
//height=height.sorted()
//InFront=InFront.sorted().reversed()
//print(height)
//print(InFront)
//for i in 0..<height.count{
//    height[InFront[i]]=height[i]
//}
////print(height)
//var height=[5,3,2,6,1,4]
//var Infront=[0,1,2,0,3,2]
//
//for (index,tall) in height.enumerated(){
//    var count=0
//    if(index != Infront[index]){
//        for i in 0..<index{
//            if(tall<height[i]){
//                count+=1
//            }
//        }
//        print(tall,count,Infront[index])
//    }
//    if(index != Infront[index]){
//    if(count != Infront[index]){
//        var temp=height.remove(at: Infront[index])
//        height.insert(temp, at: count)
//        }
//    }
//}
//print(height)
//indirect enum Calculator {
//    case number(Double)
//    case addition(Calculator, Calculator)
//    case multiplication(Calculator, Calculator)
//    case subtraction(Calculator,Calculator)
//    case division(Calculator,Calculator)
//}
//let firstVariable = Calculator.number(9)
//let secondVariable = Calculator.number(8)
//let sum = Calculator.addition(firstVariable,secondVariable)
//let product = Calculator.multiplication(firstVariable, secondVariable)
//let divide = Calculator.division(firstVariable, secondVariable)
//let subtract = Calculator.subtraction(firstVariable, secondVariable)
//
//func evaluate(_ expression: Calculator) -> Double {
//    switch expression {
//    case let .number(value):
//        return value
//    case let .addition(left, right):
//        return evaluate(left) + evaluate(right)
//    case let .multiplication(left, right):
//        return evaluate(left) * evaluate(right)
//    case let .subtraction(left, right):
//        return evaluate(left) - evaluate(right)
//        case let .division(left, right):
//        return evaluate(left)/evaluate(right)
//    }
//}
//print(evaluate(product))
//
//print(evaluate(sum))
//
//print(evaluate(divide))
//
//print(evaluate(subtract))
//
//var gcf=[12,18,36]
//var small=gcf[0]
//var hcf=0,count=0
//var j=1
//for i in 2...small{
//     count=0
//    for j in 0..<gcf.count{
//        if(gcf[j]%i == 0){
//          count+=1
//        }
//    }
//    if(count==gcf.count){
//        hcf=i
//    }
//}
//print(hcf)

//var gcf = [12,18,36]
//var small=gcf[0]
//var hcf=0,count=0,i=1,j=0
//
//repeat{
//    i+=1
//    count=0
//    j=0
//    while (j<gcf.count){
//
//        if gcf[j]%i == 0 {
//            count+=1
//        }
//        j+=1
//    }
//    if(count==gcf.count){
//        hcf=i
//    }
//}while(i<small )
//
//print(hcf)

//struct Size {
//    var width = 0.0, height = 0.0
//}
//struct Point {
//    var x = 0.0, y = 0.0
//}
//struct Rect {
//    var origin = Point()
//    var size = Size()
//    init() {}
//    init(origin: Point, size: Size) {
//        self.origin = origin
//        self.size = size
//    }
//    init(center: Point, size: Size) {
//        let originX = center.x - (size.width / 2)
//        let originY = center.y - (size.height / 2)
//        self.init(origin: Point(x: originX, y: originY), size: size)
//    }
//}
//let basicrect=Rect(origin: Point(x: 3.0, y: 2.0), size: Size(width: 4.0, height: 5.0))
//print(basicrect.origin)
//print(basicrect.size)
//print(basicrect.self)
//class Duplicate{
//    var name = "harsh"
//    func find(){
//        var names=Array(name)
//for i in 0..<names.count{
//    for j in (i+1)..<names.count{
//        if(names[i]==names[j]){
//            print(names[i])
//                }
//            }
//        }
//    }
//}
//var duplicate = Duplicate()
//duplicate.find()
//class MultipleDuplicate{
//var number=[5,4,5,4,3,4,7,7,7,7,7,7,7]
//    func find(){
//    var check = [Int]()
//
//for i in 0..<number.count{
//    for j in (i+1)..<number.count{
//        if(number[i]==number[j]){
//            if(check.contains(number[i])){
//                continue
//        }
//                else{
//                    check.append(number[i])
//                    }
//                }
//            }
//        }
//
//   print(check)
//
//    }
//}
//var multipleduplicate = MultipleDuplicate()
//multipleduplicate.find()

//struct Number{
//var n=1024
//var m=0
//}
//var number = Number()
//
//number.m=number.n
//while(number.n != 1){
//    if(number.n%2 != 0){
//        print("\(number.m) is Not a power of 2")
//        break
//    }
//    number.n=number.n/2
//}
//if(number.n==1){
//    print("\(number.m) is a power of 2")
//}
//enum VendingMachineError: Error {
//    case invalidSelection
//    case insufficientFunds(coinsNeeded: Int)
//    case outOfStock
//}
//
//struct Item {
//    var price: Int
//    var count: Int
//}
//
//class VendingMachine {
//    var inventory = [
//        "Candy Bar": Item(price: 12, count: 7),
//        "Chips": Item(price: 10, count: 4),
//        "Pretzels": Item(price: 7, count: 11)
//    ]
//    var coinsDeposited = 0
//
//    func vend(itemNamed name: String) throws {
//        guard let item = inventory[name] else {
//            throw VendingMachineError.invalidSelection
//        }
//
//        guard item.count > 0 else {
//            throw VendingMachineError.outOfStock
//        }
//
//        guard item.price <= coinsDeposited else {
//            throw VendingMachineError.insufficientFunds(coinsNeeded: item.price - coinsDeposited)
//        }
//
//        coinsDeposited -= item.price
//
//        var newItem = item
//        newItem.count -= 1
//        inventory[name] = newItem
//
//        print("Dispensing \(name)")
//    }
//}
//var vendingmachine=VendingMachine()
//print(vendingmachine.inventory)
//vendingmachine.coinsDeposited=123
//print(try vendingmachine.vend(itemNamed: "Candy Bar"))
//let favoriteSnacks = [
//    "Alice": "Chips",
//    "Bob": "Licorice",
//    "Eve": "Pretzels",
//]
//func buyFavoriteSnack(person: String, vendingMachine: VendingMachine) throws {
//    let snackName = favoriteSnacks[person] ?? "Candy Bar"
//    try vendingMachine.vend(itemNamed: snackName)
//}
//struct PurchasedSnack {
//    let name: String
//    init(name: String, vendingMachine: VendingMachine) throws {
//        try vendingMachine.vend(itemNamed: name)
//        self.name = name
//    }
//}

//class MediaItem{
//    var name: String
//    init(name: String) {
//        self.name=name
//    }
//}

//class Movie: MediaItem{
//    var director : String
//    init(name: String,director:String) {
//        self.director=director
//        super.init(name: name)
//    }
//}
//class Song:MediaItem{
//    var artist:String
//    init(name:String,artist:String) {
//        self.artist=artist
//        super.init(name: name)
//    }
//}
//
//let library=[
//    Movie(name: "Casablanca", director: "Michael Curtiz"),
//    Song(name: "Blue Suede Shoes", artist: "Elvis Presley"),
//    Movie(name: "Citizen Kane", director: "Orson Welles"),
//    Song(name: "The One And Only", artist: "Chesney Hawkes"),
//    Song(name: "Never Gonna Give You Up", artist: "Rick Astley")
//]
//var moviecount=0,songcount=0
//
//
//for item in library{
//    if let movie = item as? Movie{
//        print("Movie:\(movie.name), dir:\(movie.director)")
//    }
//    else if let song=item as? Song{
//        print("Song:\(song.name),artist:\(song.artist)")
//    }
//}

//struct BlackjackCard {
//
//    // nested Suit enumeration
//    enum Suit: Character {
//        case spades = "♠", hearts = "♡", diamonds = "♢", clubs = "♣"
//    }
//
//    // nested Rank enumeration
//    enum Rank: Int {
//        case two = 2, three, four, five, six, seven, eight, nine, ten
//        case jack, queen, king, ace
//        struct Values {
//            let first: Int, second: Int?
//        }
//        var values: Values {
//            switch self {
//            case .ace:
//                return Values(first: 1, second: 11)
//            case .jack, .queen, .king:
//                return Values(first: 10, second: nil)
//            default:
//                return Values(first: self.rawValue, second: nil)
//            }
//        }
//    }
//
//    // BlackjackCard properties and methods
//    let rank: Rank, suit: Suit
//    var description: String {
//        var output = "suit is \(suit.rawValue),"
//        output += " value is \(rank.values.first)"
//        if let second = rank.values.second {
//            output += " or \(second)"
//        }
//        return output
//    }
//}
//
//let theAceOfSpades = BlackjackCard(rank: .king, suit: .spades)
//print("theAceOfSpades: \(theAceOfSpades.description)")
//
//let heartSymbol = BlackjackCard.Suit.hearts.rawValue
//print(heartSymbol)

//extension Double{
//    var km: Double{    return self*1000.0    }
//    var cm: Double { return self/100.0}
//    var mm: Double { return self/1000.0}
//
//}
//var check = 2.km
//print(check)
//var check2 = 2.cm
//print(check2)
//extension Int{
//    mutating func square(){
//        self=self*self
//    }
//}
//var se = 3
//se.square()
//print(se)
//
//extension Int{
//    subscript(index:Int)->Int{
//
//        var indexbase=1
//        for _ in 0..<index{
//            indexbase*=10
//        }
//        return (self/indexbase)%10
//    }
//}
//print(123[1])

//protocol RandomGenerator{
//    func random()->Double
//}
//class Generator:RandomGenerator{
//    var lastRandom = 42.0
//    let m = 13.0
//    let a = 3.0
//    let c = 2.0
//    func random() -> Double {
//        lastRandom = (lastRandom * a+c).truncatingRemainder(dividingBy: m)
//        return lastRandom / m
//    }
//}
//let generator=Generator()
//print(generator.random())
//print(generator.random())
//print(generator.random())

//protocol Name{
//    var name:String { get }
//}
//protocol Age {
//    var age: String { get }
//}
//struct Birthday:Name,Age {
//    var name: String
//    var age: String
//}
//func Wish(to celeb:Name & Age){
//    print("Happy Birthday \(celeb.name) to age \(celeb.age)")
//}
//let person = Birthday(name: "Harsh", age: "21")
//Wish(to: person)

//protocol HasArea{
//    var area:Double{ get }
//}
//
//class Circle: HasArea{
//    let pi=3.14
//    var radius: Double
//    var area:Double{ return pi*radius}
//    init(radius:Double) {
//        self.radius=radius
//    }
//}
//class Country: HasArea{
//    var area:Double
//    init(area:Double) {
//        self.area=area
//    }
//}
//class Animal {
//    var legs:Int
//    init(legs:Int) {
//        self.legs=legs
//    }
//}
//let objects: [AnyObject]=[
//    Circle(radius:2.5),
//    Country(area:23456.6),
//    Animal(legs:4)
//]
//
//for object in objects{
//    if let objectWithArea = object as? HasArea {
//        print("Area is \(objectWithArea.area)" )
//    }
//    else{
//        print("It is something else")
//    }
//}
//
//func swapTwoValues<swap>(_ a: inout swap,_ b: inout swap){
//    let temporary=a
//    a=b
//    b=temporary
//}
//
//var first = 12
//var second = 5
//swapTwoValues(&first, &second)
//print(first,second)
//
//var first1 = "Hello"
//var second2 = "World"
//swapTwoValues(&first1 , &second2)
//print(first1,second2)
//
//swap(&first, &second)
//print(first,second)
//
//swap(&first1, &second2)
//print(first1,second2)

//struct Stack<Element>{
//    var stack=[Element]()
//    mutating func push(_ a:Element){
//        stack.append(a)
//    }
//    mutating func pop(){
//        stack.removeLast()
//    }
//}
//
//var value=Stack<String>()
//value.push("a")
//value.push("b")
//value.push("c")
//value.push("d")
//
//print(value.stack)
//value.pop()
//print(value.stack)
//
//extension Stack{
//    var top : Element?{
//        return stack.isEmpty ? nil :stack[stack.count-1]
//    }
//}
//print(value.top!)


//func findIndex<T:Equatable>(from str:T,in array:[T]) -> Int? {
//
//    for (index,value) in array.enumerated(){
//        if value == str{
//            return index
//        }
//    }
//    return nil
//}
//
//var string=["hel","no","yes"]
//if let index = findIndex(from: "no", in: string)
//{
//    print(index)
//}
//func draw()->String{
//var result=[String]()
//for length in 1...3 {
//    result.append(String(repeating: "*", count: length))
//    }
//    return result.joined(separator: "\n")
//}
//print(draw())
//
//class Country {
//    let name: String
//    var capitalCity: City!
//    init(name: String, capitalName: String) {
//        self.name = name
//        self.capitalCity = City(name: capitalName, country: self)
//    }
//}
//
//class City {
//    let name: String
//    unowned let country: Country
//    init(name: String, country: Country) {
//        self.name = name
//        self.country = country
//    }
//}
//
//var country = Country(name: "Canada", capitalName: "Ottawa")
//print("\(country.name)'s capital city is called \(country.capitalCity.name)")
//var stepSize = 1
//var copyofstepsize=stepSize
//func increment(_ number: inout Int) {
//    number += stepSize
//}
//
//increment(&copyofstepsize)
//stepSize=copyofstepsize
//print(stepSize)
//var check = #"""
//Here are three more double quotes: """
//"""#
//print(check)
//print(#"Write an interpolated string in Swift using \(multiplier)."#)
//// Prints "Write an interpolated string in Swift using \(multiplier)."
//print(#"6 times 7 is \#(6 * 7)."#)
//func max<T>(_ x: T, _ y: T) -> T where T: Comparable { }

//func balance(_ x: inout Int, _ y: inout Int) {
//    let sum = x + y
//    x = sum / 2
//    y = sum - x
//}
//
//struct Player {
//    var name: String
//    var health: Int
//    var energy: Int
//
//    static let maxHealth = 10
//    mutating func restoreHealth() {
//        health = Player.maxHealth
//    }
//}
//extension Player {
//    mutating func shareHealth(with teammate: inout Player) {
//        balance(&teammate.health, &health)
//    }
//}
//
//var oscar = Player(name: "Oscar", health: 10, energy: 10)
//var maria = Player(name: "Maria", health: 5, energy: 10)
//oscar.shareHealth(with: &maria)
////maria.shareHealth(with: &oscar)
//print(maria)
//print(oscar)

//let wholeNumber: Double = 12345.0
//let pi = 3.14159
//
//if let valueMaintained = Int(exactly: wholeNumber) {
//    print("\(wholeNumber) conversion to Int maintains value of \(valueMaintained)")
//}
//// Prints "12345.0 conversion to Int maintains value of 12345"
//
//let valueChanged = Int(exactly: pi)
//// valueChanged is of type Int?, not Int
//if valueChanged == nil {
//    print("\(pi) conversion to Int does not maintain value")
//}
