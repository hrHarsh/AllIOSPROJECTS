class Duplicate{
    var name = "harsha"
    
    func find(){
        var names=Array(name)
        for i in 0..<names.count{
            for j in (i+1)..<names.count{
                if(names[i]==names[j]){
                    print(names[i])
                    }
                }
            }
        }
    }

var duplicate = Duplicate()
duplicate.find()
