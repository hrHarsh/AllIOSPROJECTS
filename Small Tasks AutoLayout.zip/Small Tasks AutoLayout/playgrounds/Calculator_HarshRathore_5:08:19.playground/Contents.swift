import UIKit

indirect enum Calculator {
    case number(Double)
    case addition(Calculator, Calculator)
    case multiplication(Calculator, Calculator)
    case subtraction(Calculator,Calculator)
    case division(Calculator,Calculator)
}
let firstVariable = Calculator.number(9)
let secondVariable = Calculator.number(8)
let sum = Calculator.addition(firstVariable,secondVariable)
let product = Calculator.multiplication(firstVariable, secondVariable)
let divide = Calculator.division(firstVariable, secondVariable)
let subtract = Calculator.subtraction(firstVariable, secondVariable)

func evaluate(_ expression: Calculator) -> Double {
    switch expression {
    case let .number(value):
        return value
    case let .addition(left, right):
        return evaluate(left) + evaluate(right)
    case let .multiplication(left, right):
        return evaluate(left) * evaluate(right)
    case let .subtraction(left, right):
        return evaluate(left) - evaluate(right)
    case let .division(left, right):
        return evaluate(left)/evaluate(right)
    }
}

print(evaluate(sum))

print(evaluate(subtract))

print(evaluate(product))

print(evaluate(divide))

