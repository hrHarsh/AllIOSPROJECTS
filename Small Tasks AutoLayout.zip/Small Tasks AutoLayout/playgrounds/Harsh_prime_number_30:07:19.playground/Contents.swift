import UIKit

func prime(a:Int,b:inout Int) {
    if(b>=2){
        if(a%b==0){
            return
        }
        else{
            b-=1
            prime(a: a, b: &b)
        }
    }
    return
}
var a=5
var b=a-1
prime(a: a, b: &b)
if(b==1){
    print("\(a) Prime number",b)
}
else {
    print("\(a) Not a prime number \(b)")
}
