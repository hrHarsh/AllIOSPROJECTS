//
//  AddElement.swift
//  CollectionView
//
//  Created by Appinventiv on 11/09/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class AddElement: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
