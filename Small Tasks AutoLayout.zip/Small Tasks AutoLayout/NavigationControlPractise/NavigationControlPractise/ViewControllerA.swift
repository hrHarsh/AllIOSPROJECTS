//
//  ViewControllerA.swift
//  NavigationControlPractise
//
//  Created by Appinventiv on 29/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewControllerA: UIViewController {
    enum AppStoryboard : String {
        case A = "ViewControllerA"
        case B = "ViewControllerB"
        case C = "ViewControllerC"
        case D = "ViewControllerD"
        case E = "ViewControllerE"
        var instance : UIStoryboard {
            return UIStoryboard(name: self.rawValue, bundle: Bundle.main)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func aButtonForRoot(_ sender: UIButton) {
        self.navigationController?.popToRootViewController(animated: true)
    }
    @IBAction func aButtonForB(_ sender: UIButton) {
        guard let vcA = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerB") as? ViewControllerB else { return  }
        self.navigationController?.pushViewController(vcA, animated: true)
    }
    
    @IBAction func aButtonForC(_ sender: UIButton) {
        guard let vcA = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerC") as? ViewControllerC else { return  }
        self.navigationController?.pushViewController(vcA, animated: true)
    }
    
     @IBAction func aButtonForD(_ sender: UIButton) {
        guard let vcA = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerD") as? ViewControllerD else { return  }
        self.navigationController?.pushViewController(vcA, animated: true)
     }
    
    @IBAction func aButtonForE(_ sender: UIButton) {
        guard let vcA = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerE") as? ViewControllerE else { return  }
        self.navigationController?.pushViewController(vcA, animated: true)
    }
    /*
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
