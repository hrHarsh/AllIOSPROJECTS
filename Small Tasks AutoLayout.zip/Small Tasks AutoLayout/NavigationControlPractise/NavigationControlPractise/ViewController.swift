//
//  ViewController.swift
//  NavigationControlPractise
//
//  Created by Appinventiv on 29/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//    enum AppStoryboard : String {
//        case A = "ViewControllerA"
//        case B = "ViewControllerB"
//        case C = "ViewControllerC"
//        case D = "ViewControllerD"
//        case E = "ViewControllerE"
//        var instance : UIStoryboard {
//            return UIStoryboard(name: self.rawValue, bundle: Bundle.main)
//        }
//    }
    var vca :UIViewController { get {
        return ((self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerA") as? ViewControllerA)!)
        } }
    var vcb :UIViewController { get {
        return ((self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerB") as? ViewControllerB)!)
        } }
    var vcc :UIViewController { get {
        return ((self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerC") as? ViewControllerC)!)
        } }
    var vcd :UIViewController { get {
        return ((self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerD") as? ViewControllerD)!)
        } }
    
    
 
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.viewControllers.append(contentsOf: [vca,vcb,vcc,vcd])
        self.navigationController?.popToRootViewController(animated: true)
        // Do any additional setup after loading the view.
    }

    @IBAction func rootButtonForA(_ sender: UIButton) {
//        guard let vcroot = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerA") as? ViewControllerA  else { return }
        self.navigationController?.pushViewController(vca, animated: true)
    }
    
    @IBAction func rootButtonForB(_ sender: UIButton) {
//        guard let vcroot = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerB") as? ViewControllerB else { return }
        self.navigationController?.pushViewController(vcb, animated: true)
    }
    
    @IBAction func rootButtonForC(_ sender: UIButton) {
//        guard let vcroot = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerC") as? ViewControllerC  else { return }
        self.navigationController?.pushViewController(vcc, animated: true)
    }
    
    @IBAction func rootButtonForD(_ sender: UIButton) {
//        guard let vcroot = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerD") as? ViewControllerD else { return }
//        self.navigationController?.viewControllers.append(contentsOf: [vca,vcb,vcc,vcd])
        self.navigationController?.pushViewController(vcd, animated: true)
    }
    
    
    @IBAction func rootButtonForE(_ sender: UIButton) {
//        guard let vcrootA = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerA") as? ViewControllerA  else { return }
//
//        guard let vcrootB = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerB") as? ViewControllerB else { return }
//
//        guard let vcrootC = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerC") as? ViewControllerC  else { return }
//
//        guard let vcrootD = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerD") as? ViewControllerD else { return }
//
        guard let vcrootE = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerE") as? ViewControllerE else { return }
//        self.navigationController?.viewControllers.append(contentsOf: [vcrootA,vcrootB,vcrootC,vcrootD])
        self.navigationController?.pushViewController(vcrootE, animated: true)
    }
}

