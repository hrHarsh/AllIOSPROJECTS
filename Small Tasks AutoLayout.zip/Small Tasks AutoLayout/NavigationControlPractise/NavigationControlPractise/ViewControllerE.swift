//
//  ViewControllerE.swift
//  NavigationControlPractise
//
//  Created by Appinventiv on 29/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewControllerE: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func eButton(_ sender: UIButton) {        self.navigationController?.popToRootViewController(animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func eButtonForA(_ sender: UIButton){
        for controller in self.navigationController!.viewControllers as Array{
            if controller.isKind(of: ViewControllerA.self){
                self.navigationController?.popToViewController(controller, animated: true)
            }
        }
        
    }
    @IBAction func eButtonForB(_ sender: UIButton){
        for controller in self.navigationController!.viewControllers as Array{
            if controller.isKind(of: ViewControllerB.self){
                self.navigationController?.popToViewController(controller, animated: true)
            }
        }
        
    }
    @IBAction func eButtonForC(_ sender: UIButton){
        for controller in self.navigationController!.viewControllers as Array{
            if controller.isKind(of: ViewControllerC.self){
                self.navigationController?.popToViewController(controller, animated: true)
            }
        }
        
        
    }
    @IBAction func eButtonForD(_ sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }

}


