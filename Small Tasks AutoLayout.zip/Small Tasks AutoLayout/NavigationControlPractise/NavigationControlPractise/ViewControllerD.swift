//
//  ViewControllerD.swift
//  NavigationControlPractise
//
//  Created by Appinventiv on 29/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewControllerD: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func dButtonForRoot(_ sender: UIButton) {
         self.navigationController?.popToRootViewController(animated: true)
    }
    
    @IBAction func dButtonForE(_ sender: UIButton) {
        guard let vcC = self.storyboard?.instantiateViewController(withIdentifier: "ViewControllerE") as? ViewControllerE else {
            return
        }
        self.navigationController?.pushViewController(vcC, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func dButtonForA(_ sender: UIButton){
        for controller in self.navigationController!.viewControllers as Array{
         if   controller.isKind(of: ViewControllerA.self){
                self.navigationController?.popToViewController(controller, animated: true)
            }
        }
        
    }
    @IBAction func dButtonForB(_ sender: UIButton){
        for controller in self.navigationController!.viewControllers as Array{
          if  controller.isKind(of: ViewControllerB.self){
                self.navigationController?.popToViewController(controller, animated: true)
            }
        }
    }
    @IBAction func dButtonForC(_ sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }

}
