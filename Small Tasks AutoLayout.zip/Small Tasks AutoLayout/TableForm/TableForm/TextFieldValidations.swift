//
//  TextFieldValidations.swift
//  TableForm
//
//  Created by Appinventiv on 10/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation
import UIKit

class  TextFieldValidattons: <#super class#> {
    <#code#>
}
