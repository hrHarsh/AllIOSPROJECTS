//
//  DataViewController.swift
//  TableForm
//
//  Created by Appinventiv on 12/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class DataViewController: UIViewController {

    @IBOutlet weak var dataReceived: UILabel!
    var dataModel : ModelData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dataReceived.text = "\(dataModel?.name)\(dataModel?.email)\(dataModel?.phone)\(dataModel?.school)\(dataModel?.city)\(dataModel?.state)\(dataModel?.qualification)\(dataModel?.college)\(dataModel?.gender)\(dataModel?.dob)\(dataModel?.empid)\(dataModel?.company)\(dataModel?.nationality)"
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
