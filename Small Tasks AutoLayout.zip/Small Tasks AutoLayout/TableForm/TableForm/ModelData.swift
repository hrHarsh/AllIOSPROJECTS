//
//  ModelData.swift
//  TableForm
//
//  Created by Appinventiv on 10/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import Foundation

struct ModelData {
    
    var name = String()
    var email = String()
    var phone = String()
    var school = String()
    var city = String()
    var state = String()
    var qualification = String()
    var college = String()
    var gender = String()
    var dob = String()
    var empid = String()
    var company = String()
    var nationality = String()
}
