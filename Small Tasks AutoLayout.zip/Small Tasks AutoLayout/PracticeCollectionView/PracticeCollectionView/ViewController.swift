//
//  ViewController.swift
//  PracticeCollectionView
//
//  Created by Appinventiv on 11/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    var imageArr = [#imageLiteral(resourceName: "Fast"),#imageLiteral(resourceName: "Echo"),#imageLiteral(resourceName: "Reverb"),#imageLiteral(resourceName: "HighPitch.png"),#imageLiteral(resourceName: "Record"),#imageLiteral(resourceName: "Stop"),#imageLiteral(resourceName: "Icon-40.png"),#imageLiteral(resourceName: "Slow"),#imageLiteral(resourceName: "Icon-40"),#imageLiteral(resourceName: "Echo"),#imageLiteral(resourceName: "LowPitch"),#imageLiteral(resourceName: "Stop")]
    override func viewDidLoad() {
        super.viewDidLoad()
        if let flowLayout =  self.collectionView.collectionViewLayout as? UICollectionViewFlowLayout{
            let widthofCell = (self.collectionView.bounds.width-20)/2
            flowLayout.itemSize = CGSize(width: widthofCell, height: widthofCell)
            flowLayout.minimumInteritemSpacing = CGFloat(10)
            flowLayout.minimumLineSpacing = CGFloat(10)
            flowLayout.scrollDirection = .horizontal
        }
    }
    
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FirstCell", for: indexPath) as? CollectionViewCell
        cell?.collectionImages.image = imageArr[indexPath.row]
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArr.count
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 5
    }
    
}

