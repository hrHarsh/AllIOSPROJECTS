//
//  CollectionViewCell.swift
//  PracticeCollectionView
//
//  Created by Appinventiv on 11/09/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var collectionImages: UIImageView!
    
}
