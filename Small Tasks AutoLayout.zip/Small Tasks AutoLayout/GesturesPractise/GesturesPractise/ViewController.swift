//
//  ViewController.swift
//  GesturesPractise
//
//  Created by Appinventiv on 27/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func handlePanGesture(recognizer:UIPanGestureRecognizer){
        let translation = recognizer.translation(in: self.view)
        if  let view = recognizer.view{
            view.center = CGPoint(x: view.center.x + translation.x,
                                  y: view.center.y + translation.y)
        }
        recognizer.setTranslation(CGPoint.zero,in: self.view)
    }
    @IBAction func handlePinchGesture(recognizer:UIPinchGestureRecognizer){
        if let view = recognizer.view{
            view.transform = view.transform.scaledBy(x: recognizer.scale, y: recognizer.scale)
            recognizer.scale = 1
        }
        
    }
    @IBAction func handleRotateGesture(recognizer:UIRotationGestureRecognizer){
        if let view = recognizer.view{
            view.transform = view.transform.rotated(by: recognizer.rotation)
            recognizer.rotation = 0
        }
    }
    @IBAction func tapPiece(_ gestureRecognizer : UITapGestureRecognizer ) {
        guard gestureRecognizer.view != nil else { return }
        
        if gestureRecognizer.state == .ended {      // Move the view down and to the right when tapped.
            print("single tap")
        }}
    
    @IBAction func longPressGesture(_ gestureRecognizer : UILongPressGestureRecognizer ) {
        guard gestureRecognizer.view != nil else { return }
        
        if gestureRecognizer.state == .ended {
            print("Long tap")
        }
        
    }
    @IBAction func swipeGesture(_ recognizer : UISwipeGestureRecognizer){
        guard recognizer.view != nil else   {return}
        
        if recognizer.state == .ended {
            recognizer.direction = .up
            //Take switch case to perform each case
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ColoredVC")
                as! ColoredVC
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
    }
    
}


