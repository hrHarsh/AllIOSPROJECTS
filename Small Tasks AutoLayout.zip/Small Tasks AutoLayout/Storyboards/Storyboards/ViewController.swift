//
//  ViewController.swift
//  Storyboards
//
//  Created by Appinventiv on 29/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelFirst: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonFirst(_ sender: UIButton) {
        let second = UIStoryboard(name: "StoryBoard2",bundle: nil)
        let vc = second.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

