//
//  ViewController.swift
//  TextViewPractise
//
//  Created by Appinventiv on 28/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var label: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let testAttach = NSTextAttachment()
        testAttach.image = UIImage(named: "Echo.png")
        textView.attributedText = NSAttributedString(attachment: testAttach)
      }

    @IBAction func changLabelButton(_ sender: Any) {
        label.text = textView.text!
        
    }
    
}

