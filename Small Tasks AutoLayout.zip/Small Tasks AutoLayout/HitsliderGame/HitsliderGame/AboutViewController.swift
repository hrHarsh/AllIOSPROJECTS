//
//  AboutViewController.swift
//  HitsliderGame
//
//  Created by Appinventiv on 12/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class AboutViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    @IBAction func close(){
        dismiss(animated: true, completion: nil)
    }

    
}
