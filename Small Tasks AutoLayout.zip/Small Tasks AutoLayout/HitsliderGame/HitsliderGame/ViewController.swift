//
//  ViewController.swift
//  HitsliderGame
//
//  Created by Appinventiv on 12/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var slider:UISlider!
    @IBOutlet weak var TargetLabel:UILabel!
    @IBOutlet weak var RoundLabel:UILabel!
    @IBOutlet weak var ScoreLabel:UILabel!
    
    var currentvalue = 0,targetValue=0,round=0,score=0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        currentvalue=Int(slider.value.rounded())
        targetValue = Int .random(in: 1...100)
        startNewRound()
        }

    @IBAction func showAlert(){
        let difference = abs(targetValue - currentvalue)
        let points = 100 - difference
        var target:String
        if difference==0{
            target = "Perfect!"
        }else if difference<5{
            target = "You almost had it!"
        }else if difference<10{
            target = "Pretty good!"
        }else{
            target = "Not even there!"
        }
        score += points
        let message = "You scored : \(points) points"
        let alert = UIAlertController(title: target, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: {
            action in
            self.startNewRound()
        })
        
        alert.addAction(action)
        
        present(alert,animated: true,completion: nil)
       // startNewRound()
    }
    @IBAction func slidermover(_ slider:UISlider){
            currentvalue = Int(slider.value.rounded())
    }
    func startNewRound(){
        currentvalue=50
        targetValue = Int .random(in: 1...100)
        slider.value = Float(currentvalue)
        updateLabels()
    }
    func updateLabels(){
        round += 1
        TargetLabel.text = String(targetValue)
        ScoreLabel.text = String(score)
        RoundLabel.text = String(round)
    }
    @IBAction func restartgame(){
        score = 0
        round=0
        updateLabels()
    }
}

