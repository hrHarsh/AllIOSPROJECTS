//
//  ViewController.swift
//  ButtonPressNextPage
//
//  Created by Appinventiv on 10/08/19.
//  Copyright © 2019 Appinventiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var UiTextField: UITextField!
    @IBOutlet weak var UiLabelField: UILabel!
    @IBOutlet weak var sliderUpdateLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do UIButton additional setup after loading the view.
    }

    @IBAction func ButtonPressed(_ sender: UIButton) {
//          UiLabelField.text=UiTextField.text
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SecondPage") as! SecondPage
//        vc.data = self.UiTextField.text!
//        self.navigationController?.pushViewController(vc, animated: true)
//
    }
    @IBAction func touchUpOutside(_ sender: UIButton) {
        UiLabelField.text = "Touch Up Outside"
    }
    //    override func prepare(for segue: UIStoryboardSegue, sender: UIButton?) {
//        let sendData: SecondPage = segue.destination as! SecondPage
//        sendData.data = UiTextField.text!
//    }

    @IBAction func touchDragOutside(_ sender: UIButton) {
        UiLabelField.text = "Touch Drag Outside"
    }
    
    @IBAction func touchDragInside(_ sender: UIButton) {
        UiLabelField.text = "Touch Drag Inside"
    }
    
    @IBAction func touchDragExit(_ sender: UIButton) {
        UiLabelField.text = "Touch Drag Exit"
    }
    
    @IBAction func touchDragEnter(_ sender: UIButton) {
        UiLabelField.text = "Touch Drag Enter"
    }
    @IBAction func touchDownRepeat(_ sender: UIButton) {
        UiLabelField.text = "Touch Down Repeat"
    }
    
    @IBAction func touchCancel(_ sender: UIButton) {
        UiLabelField.text = "Touch Cancel"
    }
    
    @IBAction func primaryActionTriggered(_ sender: UIButton) {
        UiLabelField.text = "Primary Action Triggered"
    }
    
    @IBAction func editingDidEnd(_ sender: UIButton) {
        UiLabelField.text = "Editing did end"
    }
    
    @IBAction func editingDidBegin(_ sender: UIButton) {
        UiLabelField.text = "Editing did begin"
    }
    
    @IBAction func editingChanged(_ sender: UIButton) {
        UiLabelField.text = "editing changed"
    }
    
    @IBAction func didEndOnExit(_ sender: UIButton) {
        UiLabelField.text = "Touch Drag Enter"
    }
    @IBAction func touchUpInside(_ sender: UIButton) {
        UiLabelField.text = "Touch Up Inside"
    }
    
    @IBAction func editingDidChange(_ sender: UISlider) {
        sliderUpdateLabel.text = String(Int(slider.value))
    }
}

